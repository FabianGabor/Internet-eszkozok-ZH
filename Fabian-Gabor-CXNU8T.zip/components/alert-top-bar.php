<div class="position-fixed top-0 start-0 end-0" style="z-index:9999">
    <div class="container">
        <div id="flash-message" class="alert fade d-none">&nbsp;</div>
        <div id="ajax-flash-message"></div>
    </div>
</div>