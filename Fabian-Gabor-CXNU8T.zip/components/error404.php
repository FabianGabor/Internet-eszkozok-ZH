<div class="row">
    <div class="col">
        <p class="text-huge text-center">404 HIBA</p>
    </div>
</div>